extends Area2D

@export_file("*.tscn") var destination_scene: String

@onready var label: Label = $"../Label"
@onready var transition_scene: CanvasLayer = $TransitionScene

var player_inside := false

func _on_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		player_inside = true
		label.visible = true

func _on_body_exited(body: Node2D) -> void:
	if body is CharacterBody2D:
		player_inside = false
		label.visible = false

func _unhandled_input(event: InputEvent) -> void:
	if player_inside and event.is_action_pressed("interact"):
		if destination_scene != "":
			transition_scene.transition_to(destination_scene)
