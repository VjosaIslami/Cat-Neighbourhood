extends Area2D
@onready var label: Label = $"../Label"
@onready var transition_scene: CanvasLayer = $TransitionScene

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_F:
			transition_scene.transition_to("res://scenes/house.tscn")

func _on_body_entered(body: CharacterBody2D) -> void:
	label.visible = true
	_input("interact")

func _on_body_exited(body: Node2D) -> void:
	label.visible = false
